@echo off
setlocal enabledelayedexpansion

:: Check if required parameters are provided
if "%~2"=="" (
    echo Usage: %0 folder_path word_list_file
    echo Example: %0 C:\MyFolder word_list.txt
    exit /b 1
)

:: Set parameters
set "folder=%~1"
set "word_list=%~2"

:: Verify folder exists
if not exist "%folder%" (
    echo Error: Folder "%folder%" does not exist
    exit /b 1
)

:: Verify word list file exists
if not exist "%word_list%" (
    echo Error: Word list file "%word_list%" does not exist
    exit /b 1
)

:: Create temporary directory for processing
set "temp_dir=%temp%\word_replace_temp"
if not exist "%temp_dir%" mkdir "%temp_dir%"

echo Scanning files in %folder%...
echo Using word list: %word_list%

:: Process each .txt file in the folder
for %%F in ("%folder%\*.*") do (
    echo Processing: %%~nxF
    set "temp_file=%temp_dir%\%%~nxF"
    copy "%%F" "!temp_file!" >nul
    
    :: Read word list and perform replacements
    for /f "tokens=1,2 delims=," %%A in (%word_list%) do (
        echo  - Replacing "%%A" with "%%B"
        powershell -Command "(Get-Content '!temp_file!') -replace '\b%%A\b', '%%B' | Set-Content '!temp_file!.tmp'"
        move /Y "!temp_file!.tmp" "!temp_file!" >nul
    )
    
    :: Replace original file with modified file
    if exist "!temp_file!" (
        move /Y "!temp_file!" "%%F" >nul
        echo  - Replacement complete
    ) else (
        echo  - Error processing file
    )
)

:: Clean up temporary directory
rd /s /q "%temp_dir%"

echo.
echo Replacement process completed.
pause