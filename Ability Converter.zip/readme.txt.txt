Hi Everyone,
            Put this script together so that when you create a json file and have old ability names, it will convert to the new ability name. Here is how it works.

1. Open the zipfile 